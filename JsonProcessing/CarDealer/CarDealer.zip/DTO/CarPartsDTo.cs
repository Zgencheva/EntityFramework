﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DTO
{
    public class CarPartsDTo
    {
        public int? PartId { get; set; }
     
    }
}
