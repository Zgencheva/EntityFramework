﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftJail.Data.Models.Enums
{
    public enum Weapon
    {
        Knife,
        FlashPulse,
        ChainRifle,
        Pistol,
        Sniper,
    }
}
